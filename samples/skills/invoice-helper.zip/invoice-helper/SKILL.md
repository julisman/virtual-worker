---
name: Invoice Helper
description: Draft a simple invoice from line items.
when_to_use: When the user asks to create or draft an invoice.
version: 1.0.0
---

# Invoice Helper

When asked to draft an invoice, first load the layout with
`load_skill_resource({"slug": "invoice-helper", "path": "references/template.txt"})`
and fill it in with the customer, line items, and totals. Always end with the footer:

> Thank you for your business — AsetIn Studio
